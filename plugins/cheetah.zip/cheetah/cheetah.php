<?php
/**
 * Plugin Name:       Cheetah Performance
 * Plugin URI:        https://www.themeum.com/
 * Description:       Companion performance plugin by Themeum.
 * Version:           1.0.0
 * Author:            Themeum.com
 * Author URI:        https://www.themeum.com/
 * Text Domain:       cheetah
 * Requires at least: 5.0
 * Tested up to:      5.5.3
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 *
 * @package Cheetah
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

// Plugin specific constants.
define( 'CHEETAH_LICENSE', 'free' );
define( 'CHEETAH_VERSION', '1.0.0' );
define( 'CHEETAH_DIR_URL', plugin_dir_url( __FILE__ ) );
define( 'CHEETAH_DIR_PATH', plugin_dir_path( __FILE__ ) );

// Require autoload.
if ( file_exists( dirname( __FILE__ ) . '/vendor/autoload.php' ) ) :
	require_once dirname( __FILE__ ) . '/vendor/autoload.php';
endif;

// Initialize classes.
if ( class_exists( 'Cheetah\\Init' ) ) :
	Cheetah\Init::register_services();
endif;

// Handles stuff at plugin activation.
register_activation_hook( __FILE__, 'cheetah_activated' );

function cheetah_activated() {
	$installed_time = get_option( 'cheetah_installed_at' );

	if ( ! $installed_time ) {
		update_option( 'cheetah_installed_at', time() );
	}

	update_option( 'cheetah_version', CHEETAH_VERSION );
}
