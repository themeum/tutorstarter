<?php
/**
 * Handles Dashboard Admin Menu Registration
 *
 * @package Cheetah
 */

namespace Cheetah\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Dashboard class
 */
class Dashboard {

	/**
	 * Register
	 */
	public function register() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'rest_api_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Add admin menu
	 */
	public function add_admin_menu() {

		$theme_name = wp_get_theme()->get( 'Name' );

		$page_title  = __( 'Cheetah Performance', 'cheetah' );
		$menu_title  = __( 'Cheetah Performance', 'cheetah' );
		$capability  = 'manage_options';
		$parent_slug = ( 'Qubely Starters' === $theme_name ? 'qubelystarters' : 'plugins.php' );
		$menu_slug   = 'cheetah';
		$callback    = array( $this, 'markup' );

		add_submenu_page( $parent_slug, $page_title, __( 'Performance', 'cheetah' ), $capability, $menu_slug, $callback );
	}

	/**
	 * Callback
	 */
	public function markup() {
		echo '<div class="wrap"><div id="cheetah"></div></div>';
	}

	/**
	 * Register settings
	 */
	public function register_settings() {

		register_setting(
			'cheetah_settings',
			'opt_block_external_http',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => false,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_defer_css',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => false,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_defer_js',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_disable_comments',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => false,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_disable_embed',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => false,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_disable_emoji',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_disable_feeds',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => false,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_disable_jquery_migrate',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_disable_rsd',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_disable_shortlinks',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_disable_version_numbers',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_disable_wlwmanifest',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_disable_wp_version',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_disable_xmlrpc',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_jquery_to_footer',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_limit_comments_js',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_limit_revisions',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_remove_comments_style',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
		register_setting(
			'cheetah_settings',
			'opt_slow_heartbeat',
			array(
				'type'              => 'boolean',
				'show_in_rest'      => true,
				'default'           => true,
				'sanitize_callback' => isset( $input ) ? true : false,
			)
		);
	}
}

