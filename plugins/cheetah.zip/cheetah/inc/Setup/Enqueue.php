<?php
/**
 * Handles registering styles and scripts
 *
 * @package Cheetah
 */

namespace Cheetah\Setup;

defined( 'ABSPATH' ) || exit;

/**
 * Enqueue class
 */
class Enqueue {

	/**
	 * Register
	 */
	public function register() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
	}

	/**
	 * Enqueue admin scripts
	 */
	public function enqueue_admin_scripts() {
		wp_enqueue_style( 'cheetah', CHEETAH_DIR_URL . '/assets/css/performance.css', array( 'wp-components' ), CHEETAH_VERSION, 'all' );

		if ( ! isset( $_GET['page'] ) || 'cheetah' !== $_GET['page'] ) {
			return;
		}
		wp_enqueue_script( 'cheetah', CHEETAH_DIR_URL . '/assets/js/performance.js', array( 'wp-api', 'wp-i18n', 'wp-components', 'wp-element' ), CHEETAH_VERSION, true );
	}
}
