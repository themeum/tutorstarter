<?php
/**
 * Handles stuff during plugin uninstallation
 *
 * @package Cheetah
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$performance_options = array(
	'opt_defer_js',
	'opt_defer_css',
	'opt_disable_rsd',
	'opt_disable_emoji',
	'opt_disable_xmlrpc',
	'opt_disable_embed',
	'opt_disable_feeds',
	'opt_slow_heartbeat',
	'opt_limit_revisions',
	'opt_jquery_to_footer',
	'opt_disable_comments',
	'opt_limit_comments_js',
	'opt_disable_shortlinks',
	'opt_disable_wp_version',
	'opt_disable_wlwmanifest',
	'opt_block_external_http',
	'opt_remove_comments_style',
	'opt_disable_jquery_migrate',
	'opt_disable_version_numbers',
	'cheetah_version',
	'cheetah_installed_at',
);

foreach ( $performance_options as $option_name ) {
	delete_option( $option_name );
}
